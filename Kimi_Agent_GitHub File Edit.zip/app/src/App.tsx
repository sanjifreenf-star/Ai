import { useState, useRef, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger,
} from '@/components/ui/dialog'
import { Label } from '@/components/ui/label'
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select'
import {
  Sheet, SheetContent, SheetHeader, SheetTitle,
} from '@/components/ui/sheet'
import { Toaster, toast } from 'sonner'
import {
  Send, Bot, User, Code, Trash2, Loader2, Github, Settings,
  FolderOpen, FileText, ChevronRight, ChevronLeft, Save,
  Plus, Eye, Edit3, Check, RefreshCw, GitBranch, Lock, Unlock,
  MessageSquare, PlusCircle, Zap, Star, X, Copy, CheckCheck,
  PanelLeftClose, PanelLeft, Search,
} from 'lucide-react'
import type { Message, Conversation, Repo, RepoContent } from '@/types'
import { AVAILABLE_MODELS, streamAI } from '@/lib/ai-api'
import {
  verifyGithubToken, fetchRepos, fetchRepoContents, fetchFileContent,
  saveFile, getRepoInfo,
} from '@/lib/github-api'
import { parseGithubCommands, stripGithubCommands, hasGithubActions, genId, formatFileSize } from '@/lib/command-parser'
import {
  getAllConversations, getCurrentConversationId, setCurrentConversationId,
  createNewConversation, updateConversationMessages, deleteConversation,
  getGithubToken, setGithubToken, removeGithubToken, getSelectedModelId, setSelectedModelId as saveSelectedModelId,
} from '@/lib/storage'

// ═══════════════════════════════════════════════════════════════════════
//  CodeBot AI — Powerful Multi-Model Coding Agent
// ═══════════════════════════════════════════════════════════════════════

export default function App() {
  // ─── State ─────────────────────────────────────────────────────────
  const [conversations, setConversations] = useState<Conversation[]>([])
  const [currentConvId, setCurrentConvId] = useState<string | null>(null)
  const [messages, setMessages] = useState<Message[]>([])
  const [input, setInput] = useState('')
  const [isLoading, setIsLoading] = useState(false)
  const [selectedModelId, setSelectedModelId] = useState(getSelectedModelId())
  const [showSidebar, setShowSidebar] = useState(true)
  const [copiedId, setCopiedId] = useState<string | null>(null)

  const scrollRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLInputElement>(null)

  // GitHub state
  const [githubToken, setGithubTokenState] = useState(getGithubToken)
  const [githubUser, setGithubUser] = useState<{ login: string; avatar_url: string } | null>(null)
  const [showSettings, setShowSettings] = useState(false)
  const [showRepoBrowser, setShowRepoBrowser] = useState(false)
  const [repos, setRepos] = useState<Repo[]>([])
  const [selectedRepo, setSelectedRepo] = useState<string | null>(null)
  const [repoContents, setRepoContents] = useState<RepoContent[]>([])
  const [currentPath, setCurrentPath] = useState('')
  const [fileContent, setFileContent] = useState('')
  const [viewingFile, setViewingFile] = useState<RepoContent | null>(null)
  const [isEditingFile, setIsEditingFile] = useState(false)
  const [isCreatingFile, setIsCreatingFile] = useState(false)
  const [newFileName, setNewFileName] = useState('')
  const [newFileContent, setNewFileContent] = useState('')
  const [repoSearch, setRepoSearch] = useState('')
  const [isLoadingRepos, setIsLoadingRepos] = useState(false)
  const [isLoadingContents, setIsLoadingContents] = useState(false)
  const [isSavingFile, setIsSavingFile] = useState(false)
  const selectedModel = AVAILABLE_MODELS.find((m) => m.id === selectedModelId) || AVAILABLE_MODELS[0]

  // ─── Init ──────────────────────────────────────────────────────────
  useEffect(() => {
    const convs = getAllConversations()
    setConversations(convs)
    const currentId = getCurrentConversationId()
    if (currentId && convs.find((c) => c.id === currentId)) {
      setCurrentConvId(currentId)
      const conv = convs.find((c) => c.id === currentId)
      if (conv) setMessages(conv.messages)
    } else if (convs.length > 0) {
      setCurrentConvId(convs[0].id)
      setMessages(convs[0].messages)
    } else {
      startNewChat()
    }
    if (githubToken) verifyToken(githubToken)
  }, [])

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight
    }
  }, [messages])

  useEffect(() => {
    inputRef.current?.focus()
  }, [isLoading])

  // ─── Helpers ───────────────────────────────────────────────────────
  const verifyToken = async (token: string) => {
    try {
      const user = await verifyGithubToken(token)
      setGithubUser({ login: user.login, avatar_url: user.avatar_url })
      setGithubTokenState(token)
      setGithubToken(token)
    } catch {
      setGithubUser(null)
    }
  }

  const startNewChat = () => {
    const conv = createNewConversation()
    setConversations((prev) => [conv, ...prev.filter((c) => c.id !== conv.id)])
    setCurrentConvId(conv.id)
    setMessages(conv.messages)
  }

  const loadConversation = (id: string) => {
    const conv = conversations.find((c) => c.id === id)
    if (conv) {
      setCurrentConvId(id)
      setCurrentConversationId(id)
      setMessages(conv.messages)
    }
  }

  const deleteConv = (id: string) => {
    deleteConversation(id)
    setConversations((prev) => prev.filter((c) => c.id !== id))
    if (currentConvId === id) {
      const remaining = conversations.filter((c) => c.id !== id)
      if (remaining.length > 0) {
        loadConversation(remaining[0].id)
      } else {
        startNewChat()
      }
    }
  }

  const onModelChange = (modelId: string) => {
    setSelectedModelId(modelId)
    saveSelectedModelId(modelId)
  }

  // ─── Send Message ──────────────────────────────────────────────────
  const sendMessage = async () => {
    if (!input.trim() || isLoading || !currentConvId) return

    const userMsg: Message = {
      id: genId(),
      role: 'user',
      content: input.trim(),
      timestamp: Date.now(),
    }

    const newMessages = [...messages, userMsg]
    setMessages(newMessages)
    updateConversationMessages(currentConvId, newMessages)
    setInput('')
    setIsLoading(true)

    const assistantId = genId()
    setMessages((prev) => [...prev, { id: assistantId, role: 'assistant', content: '', timestamp: Date.now(), model: selectedModel.name }])

    try {
      let fullContent = ''
      for await (const chunk of streamAI(selectedModel, newMessages)) {
        if (chunk.content) {
          fullContent += chunk.content
          setMessages((prev) =>
            prev.map((m) => (m.id === assistantId ? { ...m, content: fullContent } : m))
          )
        }
      }

      // Execute GitHub file operations
      const commands = parseGithubCommands(fullContent)
      if (commands.length > 0 && githubToken) {
        for (const cmd of commands) {
          try {
            const repoInfo = await getRepoInfo(githubToken, cmd.repo)
            const branch = cmd.branch || repoInfo.default_branch
            let sha: string | undefined
            if (cmd.type === 'edit') {
              try {
                const existing = await fetchFileContent(githubToken, cmd.repo, cmd.path, branch)
                sha = existing.sha
              } catch { /* file might not exist */ }
            }
            await saveFile(githubToken, cmd.repo, cmd.path, cmd.content, cmd.commit, branch, sha)
            toast.success(`${cmd.type === 'create' ? 'Created' : 'Updated'} ${cmd.path} in ${cmd.repo}`)
          } catch (err) {
            toast.error(`Failed to ${cmd.type} file: ${err instanceof Error ? err.message : ''}`)
          }
        }
      }

      // Save final state
      const finalMessages = [...newMessages, { id: assistantId, role: 'assistant' as const, content: fullContent, timestamp: Date.now(), model: selectedModel.name }]
      setMessages(finalMessages)
      updateConversationMessages(currentConvId, finalMessages)
      setConversations(getAllConversations())
    } catch (error) {
      const errMsg = `Error: ${error instanceof Error ? error.message : 'Something went wrong'}`
      setMessages((prev) =>
        prev.map((m) => (m.id === assistantId ? { ...m, content: errMsg } : m))
      )
    } finally {
      setIsLoading(false)
    }
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      sendMessage()
    }
  }

  const copyToClipboard = async (text: string, id: string) => {
    await navigator.clipboard.writeText(text)
    setCopiedId(id)
    toast.success('Copied!')
    setTimeout(() => setCopiedId(null), 2000)
  }

  // ─── Repo Browser Functions ────────────────────────────────────────
  const openRepoBrowser = async () => {
    if (!githubToken) { toast.error('Connect GitHub first in Settings'); setShowSettings(true); return }
    setIsLoadingRepos(true)
    setShowRepoBrowser(true)
    try {
      const data = await fetchRepos(githubToken)
      setRepos(data)
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Failed to load repos')
    } finally {
      setIsLoadingRepos(false)
    }
  }

  const browseRepo = async (repoFullName: string, path = '') => {
    if (!githubToken) return
    setIsLoadingContents(true)
    setCurrentPath(path)
    try {
      const data = await fetchRepoContents(githubToken, repoFullName, path)
      setRepoContents(data)
      setSelectedRepo(repoFullName)
      setViewingFile(null)
      setIsEditingFile(false)
      setIsCreatingFile(false)
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Failed')
    } finally {
      setIsLoadingContents(false)
    }
  }

  const viewFile = async (repoFullName: string, file: RepoContent) => {
    if (!githubToken) return
    setIsLoadingContents(true)
    try {
      const repo = repos.find((r) => r.full_name === repoFullName)
      const data = await fetchFileContent(githubToken, repoFullName, file.path, repo?.default_branch)
      setFileContent(data.content)
      setViewingFile({ ...file, sha: data.sha })
      setIsEditingFile(false)
      setIsCreatingFile(false)
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Failed to load file')
    } finally {
      setIsLoadingContents(false)
    }
  }

  const handleSaveFile = async () => {
    if (!githubToken || !selectedRepo || !viewingFile) return
    setIsSavingFile(true)
    try {
      const repo = repos.find((r) => r.full_name === selectedRepo)
      await saveFile(githubToken, selectedRepo, viewingFile.path, fileContent, `Update ${viewingFile.name} via CodeBot AI`, repo?.default_branch || 'main', viewingFile.sha)
      toast.success(`Saved ${viewingFile.name}!`)
      setIsEditingFile(false)
      // Refresh file
      await viewFile(selectedRepo, viewingFile)
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Save failed')
    } finally {
      setIsSavingFile(false)
    }
  }

  const handleCreateFile = async () => {
    if (!githubToken || !selectedRepo || !newFileName) return
    setIsSavingFile(true)
    try {
      const fullPath = currentPath ? `${currentPath}/${newFileName}` : newFileName
      const repo = repos.find((r) => r.full_name === selectedRepo)
      await saveFile(githubToken, selectedRepo, fullPath, newFileContent, `Create ${newFileName} via CodeBot AI`, repo?.default_branch || 'main')
      toast.success(`Created ${newFileName}!`)
      setIsCreatingFile(false)
      setNewFileName('')
      setNewFileContent('')
      await browseRepo(selectedRepo, currentPath)
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Create failed')
    } finally {
      setIsSavingFile(false)
    }
  }

  const filteredRepos = repoSearch
    ? repos.filter((r) => r.name.toLowerCase().includes(repoSearch.toLowerCase()) || (r.description && r.description.toLowerCase().includes(repoSearch.toLowerCase())))
    : repos

  // ─── Content Formatting ────────────────────────────────────────────
  const formatContent = (content: string) => {
    const stripped = stripGithubCommands(content)
    if (!stripped) return []
    const codeRegex = /```(\w+)?\n([\s\S]*?)```/g
    const parts: (string | { type: 'code'; language: string; code: string })[] = []
    let last = 0, m: RegExpExecArray | null
    while ((m = codeRegex.exec(stripped)) !== null) {
      if (m.index > last) parts.push(stripped.slice(last, m.index))
      parts.push({ type: 'code', language: m[1] || 'text', code: m[2].trim() })
      last = m.index + m[0].length
    }
    if (last < stripped.length) parts.push(stripped.slice(last))
    if (!parts.length) parts.push(stripped)
    return parts
  }

  const renderText = (text: string) => {
    return text.split(/(\*\*[\s\S]*?\*\*)/g).map((part, i) => {
      if (part.startsWith('**') && part.endsWith('**')) return <strong key={i}>{part.slice(2, -2)}</strong>
      const inline = part.split(/(`[^`]+`)/g).map((p, j) => {
        if (p.startsWith('`') && p.endsWith('`')) return <code key={j} className="bg-muted px-1.5 py-0.5 rounded text-sm font-mono">{p.slice(1, -1)}</code>
        return <span key={j}>{p}</span>
      })
      return <span key={i}>{inline}</span>
    })
  }

  // ═══════════════════════════════════════════════════════════════════
  //  RENDER
  // ═══════════════════════════════════════════════════════════════════
  return (
    <div className="flex h-screen bg-gradient-to-br from-slate-50 via-gray-50 to-zinc-100 overflow-hidden">
      <Toaster position="top-right" richColors />

      {/* ═══════ Sidebar ═══════ */}
      {showSidebar && (
        <div className="w-72 bg-white/90 backdrop-blur-md border-r border-border/50 flex flex-col">
          <div className="p-4 border-b border-border/50">
            <div className="flex items-center gap-2 mb-3">
              <div className="flex items-center justify-center w-8 h-8 rounded-lg bg-gradient-to-br from-violet-600 to-indigo-600">
                <Code className="w-4 h-4 text-white" />
              </div>
              <span className="font-bold text-slate-800">CodeBot AI</span>
            </div>
            <Button
              className="w-full bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-700 hover:to-indigo-700"
              onClick={startNewChat}
            >
              <PlusCircle className="w-4 h-4 mr-2" />
              New Chat
            </Button>
          </div>

          <ScrollArea className="flex-1">
            <div className="p-2 space-y-1">
              {conversations.map((conv) => (
                <div
                  key={conv.id}
                  className={`group flex items-center gap-2 px-3 py-2 rounded-lg cursor-pointer transition-colors ${
                    conv.id === currentConvId
                      ? 'bg-indigo-50 border border-indigo-200'
                      : 'hover:bg-slate-50 border border-transparent'
                  }`}
                  onClick={() => loadConversation(conv.id)}
                >
                  <MessageSquare className={`w-4 h-4 flex-shrink-0 ${conv.id === currentConvId ? 'text-indigo-600' : 'text-muted-foreground'}`} />
                  <div className="flex-1 min-w-0">
                    <p className={`text-sm truncate ${conv.id === currentConvId ? 'font-medium text-indigo-900' : 'text-slate-700'}`}>
                      {conv.title}
                    </p>
                    <p className="text-[10px] text-muted-foreground">
                      {new Date(conv.updatedAt).toLocaleDateString()}
                    </p>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="w-6 h-6 opacity-0 group-hover:opacity-100 transition-opacity"
                    onClick={(e) => { e.stopPropagation(); deleteConv(conv.id) }}
                  >
                    <Trash2 className="w-3 h-3 text-muted-foreground" />
                  </Button>
                </div>
              ))}
            </div>
          </ScrollArea>

          <div className="p-3 border-t border-border/50 space-y-2">
            {githubUser && (
              <div className="flex items-center gap-2 px-2 py-1.5 bg-emerald-50 rounded-lg">
                <img src={githubUser.avatar_url} alt="" className="w-5 h-5 rounded-full" />
                <span className="text-xs text-emerald-700 font-medium truncate">{githubUser.login}</span>
              </div>
            )}
            <div className="flex items-center gap-2 px-2">
              <Zap className="w-3 h-3 text-amber-500" />
              <span className="text-[10px] text-muted-foreground">{selectedModel.name}</span>
            </div>
          </div>
        </div>
      )}

      {/* ═══════ Main Chat Area ═══════ */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Header */}
        <header className="flex items-center justify-between px-4 py-3 bg-white/80 backdrop-blur-md border-b border-border/50 shadow-sm">
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => setShowSidebar(!showSidebar)}>
              {showSidebar ? <PanelLeftClose className="w-4 h-4" /> : <PanelLeft className="w-4 h-4" />}
            </Button>

            {/* Model Selector */}
            <Select value={selectedModelId} onValueChange={onModelChange}>
              <SelectTrigger className="w-[220px] h-8 text-xs">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <div className="px-2 py-1.5 text-[10px] font-semibold text-muted-foreground uppercase">Groq Models</div>
                {AVAILABLE_MODELS.filter((m) => m.provider === 'groq').map((m) => (
                  <SelectItem key={m.id} value={m.id} className="text-xs">
                    <div className="flex items-center gap-2">
                      <Zap className="w-3 h-3 text-amber-500" />
                      <span>{m.name}</span>
                    </div>
                  </SelectItem>
                ))}
                <div className="px-2 py-1.5 text-[10px] font-semibold text-muted-foreground uppercase mt-1">Gemini Models</div>
                {AVAILABLE_MODELS.filter((m) => m.provider === 'gemini').map((m) => (
                  <SelectItem key={m.id} value={m.id} className="text-xs">
                    <div className="flex items-center gap-2">
                      <Star className="w-3 h-3 text-blue-500" />
                      <span>{m.name}</span>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            {isLoading && (
              <Badge variant="secondary" className="text-[10px] bg-amber-50 text-amber-700 border-amber-200">
                <Loader2 className="w-2.5 h-2.5 animate-spin mr-1" />
                Generating...
              </Badge>
            )}
          </div>

          <div className="flex items-center gap-1">
            {githubUser && (
              <Button variant="outline" size="sm" className="h-8 text-xs gap-1.5" onClick={openRepoBrowser}>
                <FolderOpen className="w-3.5 h-3.5" />
                Repos
              </Button>
            )}

            <Dialog open={showSettings} onOpenChange={setShowSettings}>
              <DialogTrigger asChild>
                <Button variant="ghost" size="icon" className="h-8 w-8">
                  <Settings className="w-4 h-4" />
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-md">
                <DialogHeader>
                  <DialogTitle className="flex items-center gap-2">
                    <Github className="w-5 h-5" />
                    GitHub Integration
                  </DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label>Personal Access Token</Label>
                    <Input
                      type="password"
                      placeholder="ghp_xxxxxxxxxxxxxxxxxxxx"
                      value={githubToken}
                      onChange={(e) => { setGithubTokenState(e.target.value); setGithubToken(e.target.value) }}
                    />
                    <p className="text-xs text-muted-foreground">
                      Get token at{' '}
                      <a href="https://github.com/settings/tokens" target="_blank" rel="noopener noreferrer" className="text-indigo-600 hover:underline">
                        github.com/settings/tokens
                      </a>{' '}
                      with <strong>repo</strong> scope.
                    </p>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      className="flex-1 bg-gradient-to-r from-violet-600 to-indigo-600"
                      onClick={() => { verifyToken(githubToken); setShowSettings(false) }}
                      disabled={!githubToken}
                    >
                      <Check className="w-4 h-4 mr-1" />
                      Connect
                    </Button>
                    {githubUser && (
                      <Button variant="outline" onClick={() => { removeGithubToken(); setGithubTokenState(''); setGithubUser(null) }}>
                        Disconnect
                      </Button>
                    )}
                  </div>
                  {githubUser && (
                    <div className="flex items-center gap-3 p-3 bg-emerald-50 rounded-lg border border-emerald-200">
                      <img src={githubUser.avatar_url} alt="" className="w-8 h-8 rounded-full" />
                      <div>
                        <p className="text-sm font-medium text-emerald-800">{githubUser.login}</p>
                        <p className="text-xs text-emerald-600">Ready to manage repositories</p>
                      </div>
                    </div>
                  )}
                </div>
              </DialogContent>
            </Dialog>

            <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground" onClick={startNewChat}>
              <PlusCircle className="w-4 h-4" />
            </Button>
          </div>
        </header>

        {/* Messages */}
        <ScrollArea className="flex-1 p-4" ref={scrollRef}>
          <div className="max-w-3xl mx-auto space-y-5">
            {messages.length === 0 && (
              <div className="text-center py-16">
                <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-gradient-to-br from-violet-600 to-indigo-600 flex items-center justify-center shadow-lg shadow-indigo-500/25">
                  <Bot className="w-8 h-8 text-white" />
                </div>
                <h2 className="text-xl font-bold text-slate-800 mb-2">CodeBot AI</h2>
                <p className="text-sm text-muted-foreground max-w-md mx-auto mb-6">
                  Your powerful coding assistant with multi-model AI and GitHub integration.
                </p>
                <div className="grid grid-cols-2 gap-2 max-w-md mx-auto">
                  {[
                    'Write a React component with TypeScript',
                    'Debug this Python script',
                    'Create a README.md in my repo',
                    'Review my code for issues',
                  ].map((suggestion) => (
                    <Button
                      key={suggestion}
                      variant="outline"
                      className="text-xs h-auto py-2 px-3 justify-start"
                      onClick={() => { setInput(suggestion); inputRef.current?.focus() }}
                    >
                      {suggestion}
                    </Button>
                  ))}
                </div>
              </div>
            )}

            {messages.map((msg) => (
              <div key={msg.id} className={`flex gap-3 ${msg.role === 'user' ? 'flex-row-reverse' : 'flex-row'}`}>
                <div className={`flex-shrink-0 flex items-center justify-center w-8 h-8 rounded-lg ${msg.role === 'user' ? 'bg-slate-800' : 'bg-gradient-to-br from-violet-600 to-indigo-600'}`}>
                  {msg.role === 'user' ? <User className="w-4 h-4 text-white" /> : <Bot className="w-4 h-4 text-white" />}
                </div>

                <Card className={`max-w-[85%] border-0 shadow-md ${msg.role === 'user' ? 'bg-slate-800 text-white' : 'bg-white/90 backdrop-blur-sm'}`}>
                  <CardContent className="p-4">
                    {msg.role === 'assistant' && msg.content === '' && isLoading ? (
                      <div className="flex items-center gap-2 text-muted-foreground">
                        <Loader2 className="w-4 h-4 animate-spin" />
                        <span className="text-sm">Thinking with {selectedModel.name}...</span>
                      </div>
                    ) : (
                      <div className="space-y-3">
                        {msg.model && (
                          <Badge variant="outline" className="text-[10px] mb-1">
                            {msg.model}
                          </Badge>
                        )}
                        {formatContent(msg.content).map((part, i) =>
                          typeof part === 'string' ? (
                            <div key={i} className="text-sm leading-relaxed whitespace-pre-wrap">
                              {renderText(part)}
                            </div>
                          ) : (
                            <div key={i} className="rounded-lg overflow-hidden border border-border/50">
                              <div className="flex items-center justify-between px-3 py-1.5 bg-muted/80 border-b border-border/30">
                                <span className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">{part.language}</span>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  className="h-5 px-2 text-[10px]"
                                  onClick={() => copyToClipboard(part.code, `code-${msg.id}-${i}`)}
                                >
                                  {copiedId === `code-${msg.id}-${i}` ? <CheckCheck className="w-3 h-3 mr-1" /> : <Copy className="w-3 h-3 mr-1" />}
                                  {copiedId === `code-${msg.id}-${i}` ? 'Copied' : 'Copy'}
                                </Button>
                              </div>
                              <pre className="p-3 bg-slate-950 overflow-x-auto max-h-96 overflow-y-auto">
                                <code className="text-sm font-mono text-slate-50">{part.code}</code>
                              </pre>
                            </div>
                          )
                        )}
                        {hasGithubActions(msg.content) && (
                          <div className="flex items-center gap-2 p-2 bg-emerald-50 rounded-lg border border-emerald-200">
                            <CheckCheck className="w-4 h-4 text-emerald-600" />
                            <span className="text-xs text-emerald-700 font-medium">GitHub file operation completed</span>
                          </div>
                        )}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>
            ))}
          </div>
        </ScrollArea>

        {/* Input */}
        <div className="p-4 bg-white/80 backdrop-blur-md border-t border-border/50">
          <div className="max-w-3xl mx-auto">
            <div className="flex gap-2">
              <Input
                ref={inputRef}
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder={`Message ${selectedModel.name}...`}
                className="flex-1 h-12 text-sm bg-white border-border/50 shadow-sm focus-visible:ring-indigo-500/30"
                disabled={isLoading}
              />
              <Button
                onClick={sendMessage}
                disabled={isLoading || !input.trim()}
                className="h-12 px-6 bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-700 hover:to-indigo-700 text-white shadow-lg shadow-indigo-500/25"
              >
                {isLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
              </Button>
            </div>
            <p className="mt-2 text-[10px] text-center text-muted-foreground">
              CodeBot AI — Multi-model coding assistant. {githubUser ? 'GitHub connected.' : 'Connect GitHub for repo file management.'}
            </p>
          </div>
        </div>
      </div>

      {/* ═══════ Repo Browser Sheet ═══════ */}
      <Sheet open={showRepoBrowser} onOpenChange={setShowRepoBrowser}>
        <SheetContent side="right" className="w-[500px] sm:w-[600px] p-0 flex flex-col">
          <SheetHeader className="p-4 border-b">
            <SheetTitle className="flex items-center gap-2 text-base">
              <Github className="w-5 h-5" />
              {viewingFile ? `📝 ${viewingFile.name}` : selectedRepo ? `📁 ${selectedRepo}` : 'Your Repositories'}
            </SheetTitle>
          </SheetHeader>

          <div className="flex-1 overflow-hidden flex flex-col p-4">
            {/* Breadcrumb */}
            {selectedRepo && (
              <div className="flex items-center gap-1 mb-3 text-sm flex-wrap">
                <Button variant="ghost" size="sm" className="h-7 text-xs" onClick={() => { setSelectedRepo(null); setRepoContents([]); setCurrentPath(''); setViewingFile(null); setIsEditingFile(false); setIsCreatingFile(false) }}>
                  <ChevronLeft className="w-3 h-3 mr-1" /> Repos
                </Button>
                {!viewingFile && (
                  <>
                    <ChevronRight className="w-3 h-3 text-muted-foreground" />
                    <span className="font-medium text-xs">{selectedRepo}</span>
                    {currentPath && (
                      <>
                        <ChevronRight className="w-3 h-3 text-muted-foreground" />
                        <span className="text-muted-foreground text-xs truncate max-w-[200px]">{currentPath}</span>
                      </>
                    )}
                  </>
                )}
                {viewingFile && (
                  <>
                    <ChevronRight className="w-3 h-3 text-muted-foreground" />
                    <Button variant="ghost" size="sm" className="h-7 text-xs" onClick={() => { setViewingFile(null); setIsEditingFile(false) }}>
                      {selectedRepo}
                    </Button>
                    <ChevronRight className="w-3 h-3 text-muted-foreground" />
                    <span className="font-medium text-xs">{viewingFile.name}</span>
                  </>
                )}
              </div>
            )}

            {/* Repo List */}
            {!selectedRepo && (
              <>
                <div className="relative mb-3">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    placeholder="Search repositories..."
                    value={repoSearch}
                    onChange={(e) => setRepoSearch(e.target.value)}
                    className="pl-9 h-8 text-sm"
                  />
                </div>
                <ScrollArea className="flex-1">
                  {isLoadingRepos ? (
                    <div className="flex items-center justify-center py-8"><Loader2 className="w-5 h-5 animate-spin text-muted-foreground" /></div>
                  ) : (
                    <div className="space-y-1">
                      {filteredRepos.map((repo) => (
                        <Button key={repo.id} variant="ghost" className="w-full justify-start text-left h-auto py-3 px-3" onClick={() => browseRepo(repo.full_name)}>
                          <div className="flex items-start gap-3 w-full">
                            <FolderOpen className="w-5 h-5 mt-0.5 text-indigo-500 flex-shrink-0" />
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center gap-2">
                                <span className="font-medium text-sm truncate">{repo.name}</span>
                                {repo.private ? <Lock className="w-3 h-3 text-amber-500" /> : <Unlock className="w-3 h-3 text-muted-foreground" />}
                              </div>
                              {repo.description && <p className="text-xs text-muted-foreground truncate mt-0.5">{repo.description}</p>}
                              <div className="flex items-center gap-2 mt-1">
                                <Badge variant="outline" className="text-[10px] h-5"><GitBranch className="w-2.5 h-2.5 mr-1" />{repo.default_branch}</Badge>
                                <span className="text-[10px] text-muted-foreground">Updated {new Date(repo.updated_at).toLocaleDateString()}</span>
                              </div>
                            </div>
                            <ChevronRight className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                          </div>
                        </Button>
                      ))}
                    </div>
                  )}
                </ScrollArea>
              </>
            )}

            {/* File Browser */}
            {selectedRepo && !viewingFile && (
              <>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs text-muted-foreground">{repoContents.length} items</span>
                  <div className="flex gap-1">
                    <Button size="sm" variant="outline" className="h-7 text-xs gap-1" onClick={() => { setIsCreatingFile(true); setIsEditingFile(false); setNewFileName(''); setNewFileContent('') }}>
                      <Plus className="w-3 h-3" /> New File
                    </Button>
                    <Button size="sm" variant="ghost" className="h-7 w-7 p-0" onClick={() => browseRepo(selectedRepo, currentPath)}>
                      <RefreshCw className="w-3.5 h-3.5" />
                    </Button>
                  </div>
                </div>

                {isCreatingFile && (
                  <Card className="mb-3 border-indigo-200 bg-indigo-50/50">
                    <CardContent className="p-3 space-y-3">
                      <div className="flex items-center gap-2">
                        <Input placeholder="filename.ext" value={newFileName} onChange={(e) => setNewFileName(e.target.value)} className="h-8 text-sm bg-white flex-1" />
                        <Button size="sm" variant="ghost" className="h-8 w-8 p-0" onClick={() => setIsCreatingFile(false)}>
                          <X className="w-4 h-4" />
                        </Button>
                      </div>
                      <textarea
                        value={newFileContent}
                        onChange={(e) => setNewFileContent(e.target.value)}
                        placeholder="Enter file content..."
                        className="w-full h-48 p-3 text-sm font-mono bg-slate-950 text-slate-50 rounded-md resize-none focus:outline-none focus:ring-2 focus:ring-indigo-500"
                      />
                      <Button size="sm" className="bg-indigo-600 w-full" disabled={isSavingFile || !newFileName} onClick={handleCreateFile}>
                        {isSavingFile ? <Loader2 className="w-3 h-3 animate-spin mr-1" /> : <Save className="w-3 h-3 mr-1" />}
                        Create File
                      </Button>
                    </CardContent>
                  </Card>
                )}

                <ScrollArea className="flex-1">
                  {isLoadingContents ? (
                    <div className="flex items-center justify-center py-8"><Loader2 className="w-5 h-5 animate-spin text-muted-foreground" /></div>
                  ) : (
                    <div className="space-y-0.5">
                      {currentPath && (
                        <Button variant="ghost" className="w-full justify-start h-9 px-3 text-muted-foreground" onClick={() => {
                          const parent = currentPath.includes('/') ? currentPath.substring(0, currentPath.lastIndexOf('/')) : ''
                          browseRepo(selectedRepo, parent)
                        }}>
                          <ChevronLeft className="w-4 h-4 mr-2" /> ..
                        </Button>
                      )}
                      {[...repoContents]
                        .sort((a, b) => (a.type === 'dir' ? -1 : 1) - (b.type === 'dir' ? -1 : 1) || a.name.localeCompare(b.name))
                        .map((item) => (
                          <Button key={item.sha} variant="ghost" className="w-full justify-start text-left h-9 px-3" onClick={() => {
                            if (item.type === 'dir') browseRepo(selectedRepo, item.path)
                            else viewFile(selectedRepo, item)
                          }}>
                            {item.type === 'dir' ? <FolderOpen className="w-4 h-4 mr-2 text-indigo-500" /> : <FileText className="w-4 h-4 mr-2 text-slate-400" />}
                            <span className="text-sm flex-1 truncate">{item.name}</span>
                            {item.type === 'file' && item.size !== undefined && <span className="text-[10px] text-muted-foreground">{formatFileSize(item.size)}</span>}
                          </Button>
                        ))}
                    </div>
                  )}
                </ScrollArea>
              </>
            )}

            {/* File Viewer / Editor */}
            {viewingFile && (
              <div className="flex flex-col flex-1 gap-3 min-h-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <Button size="sm" variant={isEditingFile ? 'default' : 'outline'} className={isEditingFile ? 'bg-indigo-600' : ''} onClick={() => setIsEditingFile(!isEditingFile)}>
                    {isEditingFile ? <><Eye className="w-3.5 h-3.5 mr-1" /> View</> : <><Edit3 className="w-3.5 h-3.5 mr-1" /> Edit</>}
                  </Button>
                  {isEditingFile && (
                    <Button size="sm" className="bg-emerald-600" disabled={isSavingFile} onClick={handleSaveFile}>
                      {isSavingFile ? <Loader2 className="w-3.5 h-3.5 animate-spin mr-1" /> : <Save className="w-3.5 h-3.5 mr-1" />}
                      Commit Changes
                    </Button>
                  )}
                  <Button size="sm" variant="ghost" onClick={() => copyToClipboard(fileContent, `file-${viewingFile.sha}`)}>
                    {copiedId === `file-${viewingFile.sha}` ? <CheckCheck className="w-3.5 h-3.5 mr-1" /> : <Copy className="w-3.5 h-3.5 mr-1" />}
                    Copy
                  </Button>
                </div>

                {isEditingFile ? (
                  <textarea
                    value={fileContent}
                    onChange={(e) => setFileContent(e.target.value)}
                    className="flex-1 w-full p-4 text-sm font-mono bg-slate-950 text-slate-50 rounded-lg resize-none focus:outline-none focus:ring-2 focus:ring-indigo-500 min-h-0"
                    spellCheck={false}
                  />
                ) : (
                  <ScrollArea className="flex-1 min-h-0">
                    <pre className="p-4 text-sm font-mono bg-slate-950 text-slate-50 rounded-lg overflow-x-auto">
                      <code>{fileContent}</code>
                    </pre>
                  </ScrollArea>
                )}
              </div>
            )}
          </div>
        </SheetContent>
      </Sheet>
    </div>
  )
}
