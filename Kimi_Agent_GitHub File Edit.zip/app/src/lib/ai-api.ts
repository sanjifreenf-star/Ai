import type { Message, AIModel } from '@/types'

// ─── Available Models ────────────────────────────────────────────────
export const AVAILABLE_MODELS: AIModel[] = [
  {
    id: 'llama-3.3-70b-versatile',
    name: 'Llama 3.3 70B',
    provider: 'groq',
    description: 'Best overall performance for coding',
    contextWindow: 128000,
  },
  {
    id: 'llama-3.1-8b-instant',
    name: 'Llama 3.1 8B',
    provider: 'groq',
    description: 'Fast responses, good for quick tasks',
    contextWindow: 128000,
  },
  {
    id: 'llama-3-70b-specdec',
    name: 'Llama 3 70B SpecDec',
    provider: 'groq',
    description: 'Speculative decoding for speed',
    contextWindow: 8192,
  },
  {
    id: 'gemma2-9b-it',
    name: 'Gemma 2 9B',
    provider: 'groq',
    description: 'Lightweight and efficient',
    contextWindow: 8192,
  },
  {
    id: 'gemini-2.5-flash',
    name: 'Gemini 2.5 Flash',
    provider: 'gemini',
    description: 'Fast, high-quality responses',
    contextWindow: 1048576,
  },
  {
    id: 'gemini-2.0-flash',
    name: 'Gemini 2.0 Flash',
    provider: 'gemini',
    description: 'Balanced speed and quality',
    contextWindow: 1048576,
  },
  {
    id: 'gemini-1.5-pro',
    name: 'Gemini 1.5 Pro',
    provider: 'gemini',
    description: 'Best for complex coding tasks',
    contextWindow: 2097152,
  },
]

// ─── Config ──────────────────────────────────────────────────────────
const GROQ_API_KEY = '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'
const GEMINI_API_KEY = 'AIzaSyC_WkNMqvObBsDrkuuL3OcWGNXr7paUAFo'
const GROQ_BASE = 'https://api.groq.com/openai/v1'
const GEMINI_BASE = 'https://generativelanguage.googleapis.com/v1beta'

// ─── System Prompt ───────────────────────────────────────────────────
export const SYSTEM_PROMPT = `You are CodeBot AI — an elite software engineering AI assistant. You write production-quality, clean, well-documented code.

## Capabilities
- Write complete, runnable code with proper error handling
- Debug complex issues with root cause analysis
- Review code for security, performance, and style
- Create and edit files in GitHub repositories
- Explain concepts clearly with examples
- Design system architecture and APIs

## Code Quality Standards
- Always include proper error handling and edge cases
- Write clear comments for complex logic
- Use modern best practices and patterns
- Include type annotations where appropriate
- Format code consistently

## GitHub File Operations
When the user asks to create or edit a file in a repo, respond with:

[GITHUB_CREATE_FILE]
repo: owner/repo-name
path: path/to/file.ext
branch: main (or target branch)
content:
<<<FILE_CONTENT>>>
(full file content here)
<<<END_FILE_CONTENT>>>
commit: Commit message
[/GITHUB_CREATE_FILE]

[GITHUB_EDIT_FILE]
repo: owner/repo-name
path: path/to/file.ext
branch: main (or target branch)
content:
<<<FILE_CONTENT>>>
(new file content here)
<<<END_FILE_CONTENT>>>
commit: Commit message
[/GITHUB_EDIT_FILE]

Always provide complete file contents — never truncate or skip sections.`

// ─── Prepare Messages ────────────────────────────────────────────────
function prepareGroqMessages(messages: Message[], systemPrompt: string) {
  return [
    { role: 'system', content: systemPrompt },
    ...messages
      .filter((m) => m.role !== 'system')
      .map((m) => ({ role: m.role, content: m.content })),
  ]
}

function prepareGeminiMessages(messages: Message[], systemPrompt: string) {
  const history = messages
    .filter((m) => m.role !== 'system')
    .map((m) => ({
      role: m.role === 'user' ? 'user' : 'model',
      parts: [{ text: m.content }],
    }))

  return { systemPrompt, history }
}

// ─── Stream Groq ─────────────────────────────────────────────────────
export async function* streamGroq(
  modelId: string,
  messages: Message[],
  systemPrompt: string = SYSTEM_PROMPT
): AsyncGenerator<{ content: string; done: boolean }> {
  const msgs = prepareGroqMessages(messages, systemPrompt)

  const res = await fetch(`${GROQ_BASE}/chat/completions`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${GROQ_API_KEY}`,
    },
    body: JSON.stringify({
      model: modelId,
      messages: msgs,
      stream: true,
      temperature: 0.1,
      max_tokens: 8192,
    }),
  })

  if (!res.ok) {
    const err = await res.text()
    throw new Error(`Groq API error ${res.status}: ${err}`)
  }

  const reader = res.body?.getReader()
  const decoder = new TextDecoder()
  if (!reader) throw new Error('No reader')

  let buffer = ''
  while (true) {
    const { done, value } = await reader.read()
    if (done) break

    buffer += decoder.decode(value, { stream: true })
    const lines = buffer.split('\n')
    buffer = lines.pop() || ''

    for (const line of lines) {
      if (line.startsWith('data: ') && line !== 'data: [DONE]') {
        try {
          const data = JSON.parse(line.slice(6))
          const delta = data.choices?.[0]?.delta?.content
          if (delta) yield { content: delta, done: false }
        } catch { /* skip */ }
      }
    }
  }
  yield { content: '', done: true }
}

// ─── Stream Gemini ───────────────────────────────────────────────────
export async function* streamGemini(
  modelId: string,
  messages: Message[],
  systemPrompt: string = SYSTEM_PROMPT
): AsyncGenerator<{ content: string; done: boolean }> {
  const { history } = prepareGeminiMessages(messages, systemPrompt)
  const contents = history.length > 0 ? history : []

  const res = await fetch(
    `${GEMINI_BASE}/models/${modelId}:streamGenerateContent?alt=sse&key=${GEMINI_API_KEY}`,
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        systemInstruction: { parts: [{ text: systemPrompt }] },
        contents,
        generationConfig: {
          temperature: 0.1,
          maxOutputTokens: 8192,
        },
      }),
    }
  )

  if (!res.ok) {
    const err = await res.text()
    throw new Error(`Gemini API error ${res.status}: ${err}`)
  }

  const reader = res.body?.getReader()
  const decoder = new TextDecoder()
  if (!reader) throw new Error('No reader')

  let buffer = ''
  while (true) {
    const { done, value } = await reader.read()
    if (done) break

    buffer += decoder.decode(value, { stream: true })
    const lines = buffer.split('\n')
    buffer = lines.pop() || ''

    for (const line of lines) {
      if (line.startsWith('data: ')) {
        try {
          const data = JSON.parse(line.slice(6))
          const parts = data.candidates?.[0]?.content?.parts || []
          for (const part of parts) {
            if (part.text) yield { content: part.text, done: false }
          }
        } catch { /* skip */ }
      }
    }
  }
  yield { content: '', done: true }
}

// ─── Unified Stream ──────────────────────────────────────────────────
export async function* streamAI(
  model: AIModel,
  messages: Message[],
  systemPrompt?: string
): AsyncGenerator<{ content: string; done: boolean }> {
  if (model.provider === 'groq') {
    yield* streamGroq(model.id, messages, systemPrompt)
  } else {
    yield* streamGemini(model.id, messages, systemPrompt)
  }
}
