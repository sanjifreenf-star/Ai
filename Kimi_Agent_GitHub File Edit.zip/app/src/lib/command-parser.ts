import type { GitHubFileOperation } from '@/types'

// ─── Parse GitHub file operations from AI response ───────────────────
export function parseGithubCommands(content: string): GitHubFileOperation[] {
  const operations: GitHubFileOperation[] = []

  // Match CREATE_FILE blocks
  const createRegex =
    /\[GITHUB_CREATE_FILE\]\s*repo:\s*(.+?)\s*path:\s*(.+?)\s*branch:\s*(.+?)\s*content:\s*<<<FILE_CONTENT>>>([\s\S]*?)<<<END_FILE_CONTENT>>>\s*commit:\s*(.+?)\s*\[\/GITHUB_CREATE_FILE\]/g

  let match: RegExpExecArray | null
  while ((match = createRegex.exec(content)) !== null) {
    operations.push({
      type: 'create',
      repo: match[1].trim(),
      path: match[2].trim(),
      branch: match[3].trim(),
      content: match[4],
      commit: match[5].trim(),
    })
  }

  // Match EDIT_FILE blocks
  const editRegex =
    /\[GITHUB_EDIT_FILE\]\s*repo:\s*(.+?)\s*path:\s*(.+?)\s*branch:\s*(.+?)\s*content:\s*<<<FILE_CONTENT>>>([\s\S]*?)<<<END_FILE_CONTENT>>>\s*commit:\s*(.+?)\s*\[\/GITHUB_EDIT_FILE\]/g

  while ((match = editRegex.exec(content)) !== null) {
    operations.push({
      type: 'edit',
      repo: match[1].trim(),
      path: match[2].trim(),
      branch: match[3].trim(),
      content: match[4],
      commit: match[5].trim(),
    })
  }

  // Match DELETE_FILE blocks
  const deleteRegex =
    /\[GITHUB_DELETE_FILE\]\s*repo:\s*(.+?)\s*path:\s*(.+?)\s*branch:\s*(.+?)\s*sha:\s*(.+?)\s*commit:\s*(.+?)\s*\[\/GITHUB_DELETE_FILE\]/g

  while ((match = deleteRegex.exec(content)) !== null) {
    operations.push({
      type: 'delete',
      repo: match[1].trim(),
      path: match[2].trim(),
      branch: match[3].trim(),
      sha: match[4].trim(),
      commit: match[5].trim(),
      content: '',
    })
  }

  return operations
}

// ─── Strip command blocks for display ────────────────────────────────
export function stripGithubCommands(content: string): string {
  return content
    .replace(/\[GITHUB_CREATE_FILE\][\s\S]*?\[\/GITHUB_CREATE_FILE\]/g, '')
    .replace(/\[GITHUB_EDIT_FILE\][\s\S]*?\[\/GITHUB_EDIT_FILE\]/g, '')
    .replace(/\[GITHUB_DELETE_FILE\][\s\S]*?\[\/GITHUB_DELETE_FILE\]/g, '')
    .trim()
}

// ─── Check if content has actionable commands ────────────────────────
export function hasGithubActions(content: string): boolean {
  return parseGithubCommands(content).length > 0
}

// ─── Format file size ────────────────────────────────────────────────
export function formatFileSize(bytes: number): string {
  if (bytes === 0) return '0 B'
  const k = 1024
  const sizes = ['B', 'KB', 'MB']
  const i = Math.floor(Math.log(bytes) / Math.log(k))
  return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i]
}

// ─── Generate unique ID ──────────────────────────────────────────────
export function genId(): string {
  return Date.now().toString(36) + Math.random().toString(36).substring(2, 9)
}
