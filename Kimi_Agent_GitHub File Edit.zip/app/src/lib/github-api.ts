import type { Repo, RepoContent } from '@/types'

const GITHUB_API = 'https://api.github.com'

function headers(token: string) {
  return {
    Authorization: `token ${token}`,
    Accept: 'application/vnd.github.v3+json',
    'Content-Type': 'application/json',
  }
}

// ─── Verify Token ────────────────────────────────────────────────────
export async function verifyGithubToken(token: string) {
  const res = await fetch(`${GITHUB_API}/user`, {
    headers: { Authorization: `token ${token}`, Accept: 'application/vnd.github.v3+json' },
  })
  if (!res.ok) throw new Error('Invalid token')
  return res.json()
}

// ─── Fetch Repos ─────────────────────────────────────────────────────
export async function fetchRepos(token: string, page = 1): Promise<Repo[]> {
  const res = await fetch(
    `${GITHUB_API}/user/repos?sort=updated&per_page=100&page=${page}`,
    { headers: headers(token) }
  )
  if (!res.ok) throw new Error('Failed to fetch repos')
  return res.json()
}

// ─── Search Repos ────────────────────────────────────────────────────
export async function searchUserRepos(token: string, query: string): Promise<Repo[]> {
  const allRepos = await fetchRepos(token)
  const lower = query.toLowerCase()
  return allRepos.filter(
    (r) =>
      r.name.toLowerCase().includes(lower) ||
      (r.description && r.description.toLowerCase().includes(lower))
  )
}

// ─── Fetch Repo Contents ─────────────────────────────────────────────
export async function fetchRepoContents(
  token: string,
  repoFullName: string,
  path = '',
  branch?: string
): Promise<RepoContent[]> {
  const branchParam = branch ? `?ref=${branch}` : ''
  const res = await fetch(
    `${GITHUB_API}/repos/${repoFullName}/contents/${path}${branchParam}`,
    { headers: headers(token) }
  )
  if (!res.ok) throw new Error('Failed to fetch contents')
  const data = await res.json()
  return Array.isArray(data) ? data : [data]
}

// ─── Fetch File Content ──────────────────────────────────────────────
export async function fetchFileContent(
  token: string,
  repoFullName: string,
  filePath: string,
  branch?: string
): Promise<{ content: string; sha: string; name: string; path: string }> {
  const branchParam = branch ? `?ref=${branch}` : ''
  const res = await fetch(
    `${GITHUB_API}/repos/${repoFullName}/contents/${filePath}${branchParam}`,
    { headers: headers(token) }
  )
  if (!res.ok) throw new Error('Failed to fetch file')
  const data = await res.json()
  const decoded = data.content ? atob(data.content.replace(/\n/g, '')) : ''
  return { content: decoded, sha: data.sha, name: data.name, path: data.path }
}

// ─── Create or Update File ───────────────────────────────────────────
export async function saveFile(
  token: string,
  repoFullName: string,
  filePath: string,
  content: string,
  commitMsg: string,
  branch: string,
  sha?: string
) {
  const res = await fetch(`${GITHUB_API}/repos/${repoFullName}/contents/${filePath}`, {
    method: 'PUT',
    headers: headers(token),
    body: JSON.stringify({
      message: commitMsg,
      content: btoa(content),
      branch,
      ...(sha ? { sha } : {}),
    }),
  })
  if (!res.ok) {
    const err = await res.json()
    throw new Error(err.message || 'Failed to save file')
  }
  return res.json()
}

// ─── Delete File ─────────────────────────────────────────────────────
export async function deleteFile(
  token: string,
  repoFullName: string,
  filePath: string,
  commitMsg: string,
  branch: string,
  sha: string
) {
  const res = await fetch(
    `${GITHUB_API}/repos/${repoFullName}/contents/${filePath}`,
    {
      method: 'DELETE',
      headers: headers(token),
      body: JSON.stringify({ message: commitMsg, sha, branch }),
    }
  )
  if (!res.ok) {
    const err = await res.json()
    throw new Error(err.message || 'Failed to delete file')
  }
  return res.json()
}

// ─── Get Default Branch ──────────────────────────────────────────────
export async function getRepoInfo(token: string, repoFullName: string) {
  const res = await fetch(`${GITHUB_API}/repos/${repoFullName}`, {
    headers: headers(token),
  })
  if (!res.ok) throw new Error('Failed to get repo info')
  return res.json()
}

// ─── Create New Branch ───────────────────────────────────────────────
export async function createBranch(
  token: string,
  repoFullName: string,
  newBranch: string,
  fromBranch: string
) {
  // First get the SHA of the latest commit on fromBranch
  const refRes = await fetch(
    `${GITHUB_API}/repos/${repoFullName}/git/refs/heads/${fromBranch}`,
    { headers: headers(token) }
  )
  if (!refRes.ok) throw new Error('Failed to get branch ref')
  const refData = await refRes.json()

  const res = await fetch(`${GITHUB_API}/repos/${repoFullName}/git/refs`, {
    method: 'POST',
    headers: headers(token),
    body: JSON.stringify({
      ref: `refs/heads/${newBranch}`,
      sha: refData.object.sha,
    }),
  })
  if (!res.ok) {
    const err = await res.json()
    throw new Error(err.message || 'Failed to create branch')
  }
  return res.json()
}
