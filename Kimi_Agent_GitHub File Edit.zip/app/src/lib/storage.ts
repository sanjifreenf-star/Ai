import type { Conversation, Message } from '@/types'
import { genId } from './command-parser'

const CONVERSATIONS_KEY = 'codebot_conversations'
const CURRENT_CONV_KEY = 'codebot_current_conv'
const GITHUB_TOKEN_KEY = 'github_pat'
const SELECTED_MODEL_KEY = 'codebot_selected_model'

// ─── Conversations ───────────────────────────────────────────────────
export function getAllConversations(): Conversation[] {
  try {
    const raw = localStorage.getItem(CONVERSATIONS_KEY)
    if (!raw) return []
    const parsed = JSON.parse(raw)
    return Array.isArray(parsed) ? parsed : []
  } catch {
    return []
  }
}

export function getConversation(id: string): Conversation | null {
  const convs = getAllConversations()
  return convs.find((c) => c.id === id) || null
}

export function getCurrentConversationId(): string | null {
  return localStorage.getItem(CURRENT_CONV_KEY)
}

export function setCurrentConversationId(id: string) {
  localStorage.setItem(CURRENT_CONV_KEY, id)
}

export function saveConversation(conv: Conversation) {
  const convs = getAllConversations().filter((c) => c.id !== conv.id)
  convs.unshift(conv)
  // Keep max 50 conversations
  const trimmed = convs.slice(0, 50)
  localStorage.setItem(CONVERSATIONS_KEY, JSON.stringify(trimmed))
}

export function deleteConversation(id: string) {
  const convs = getAllConversations().filter((c) => c.id !== id)
  localStorage.setItem(CONVERSATIONS_KEY, JSON.stringify(convs))
  const current = getCurrentConversationId()
  if (current === id) {
    localStorage.removeItem(CURRENT_CONV_KEY)
  }
}

export function createNewConversation(): Conversation {
  const conv: Conversation = {
    id: genId(),
    title: 'New Chat',
    messages: [],
    createdAt: Date.now(),
    updatedAt: Date.now(),
  }
  saveConversation(conv)
  setCurrentConversationId(conv.id)
  return conv
}

export function updateConversationMessages(id: string, messages: Message[]) {
  const conv = getConversation(id)
  if (!conv) return
  conv.messages = messages
  conv.updatedAt = Date.now()
  // Auto-generate title from first user message
  if (conv.title === 'New Chat') {
    const firstUser = messages.find((m) => m.role === 'user')
    if (firstUser) {
      conv.title = firstUser.content.slice(0, 40) + (firstUser.content.length > 40 ? '...' : '')
    }
  }
  saveConversation(conv)
}

// ─── GitHub Token ────────────────────────────────────────────────────
export function getGithubToken(): string {
  return localStorage.getItem(GITHUB_TOKEN_KEY) || ''
}

export function setGithubToken(token: string) {
  localStorage.setItem(GITHUB_TOKEN_KEY, token)
}

export function removeGithubToken() {
  localStorage.removeItem(GITHUB_TOKEN_KEY)
}

// ─── Selected Model ──────────────────────────────────────────────────
export function getSelectedModelId(): string {
  return localStorage.getItem(SELECTED_MODEL_KEY) || 'llama-3.3-70b-versatile'
}

export function setSelectedModelId(modelId: string) {
  localStorage.setItem(SELECTED_MODEL_KEY, modelId)
}
