export interface Message {
  id: string
  role: 'user' | 'assistant' | 'system'
  content: string
  timestamp: number
  model?: string
}

export interface Conversation {
  id: string
  title: string
  messages: Message[]
  createdAt: number
  updatedAt: number
}

export interface AIModel {
  id: string
  name: string
  provider: 'groq' | 'gemini'
  description: string
  contextWindow: number
}

export interface Repo {
  id: number
  name: string
  full_name: string
  private: boolean
  default_branch: string
  description: string | null
  updated_at: string
}

export interface RepoContent {
  name: string
  path: string
  type: 'file' | 'dir'
  sha: string
  size?: number
  content?: string
  encoding?: string
  html_url?: string
}

export interface GitHubFileOperation {
  type: 'create' | 'edit' | 'delete'
  repo: string
  path: string
  branch: string
  content: string
  commit: string
  sha?: string
}

export interface AIStreamResponse {
  content: string
  done: boolean
}
